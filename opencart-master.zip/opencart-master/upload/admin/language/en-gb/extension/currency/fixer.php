<?php
// Heading
$_['heading_title']    = 'Fixer';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified fixer currency rates!';
$_['text_edit']        = 'Edit Fixer';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Fixer currency rates!';